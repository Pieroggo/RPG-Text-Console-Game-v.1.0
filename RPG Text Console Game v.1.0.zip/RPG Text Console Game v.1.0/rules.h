#pragma once
#include<iostream>
#include <map>
using namespace std;

void gameRules() {
	system("cls");
	cout << "Welcome to the sandbox" << endl;
	map<string, int> CommandCode;
	CommandCode.insert(pair<std::string, int>("/help", 1));
	CommandCode.insert(pair<std::string, int>("/b", 2));
	CommandCode.insert(pair<std::string, int>("/inv", 3));
	CommandCode.insert(pair<std::string, int>("/stat", 4));
	auto i = CommandCode.find("/help");
	cout << i->second<<endl;//wyszukiwanie po kodzie, dzia�a

	system("pause");
}