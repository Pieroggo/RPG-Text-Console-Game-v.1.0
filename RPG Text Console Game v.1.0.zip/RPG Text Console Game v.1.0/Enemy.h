#pragma once
#include<iostream>
#include<map>
enum class Zone {
	None = 0,
	Sewers = 1,
	Forest = 2
};
class Enemy {
private:
	string name;
	int bAtk;
	int bDef;
	int bHP;
	int dc;//dc/10000= procent drop q
	Zone zone;
public:
	
	int cAtk;
	int cDef;
	int cHP;
	std::string getName() {
		return name;
	}
	int getbAtk() {
		return bAtk;
	}
	int getbDef() {
		return bDef;
	}
	int getbHP() {
		return bHP;
	}
	int getDc() {
		return dc;
	}
	void setName(std::string a) {
		name = a;
	}
	void setbAtk(int a) {
		bAtk = a;
	}
	void setbDef(int a) {
		bDef = a;
	}
	void setbHP(int a) {
		bHP = a;
	}
	
	void setDc(int a) {
		dc = a;
	}
	void setZone(Zone a) {
		zone = a;
	}
	Enemy(){}
	Enemy(std::string name, int Atk, int Def, int HP,Zone a) {
		setName(name);
		setbAtk(Atk);
		setbDef(Def);
		setbHP(HP);
		setZone(a);
		cAtk = getbAtk();
		cDef = getbDef();
		cHP = getbHP();
	}
	
};

