#pragma once
#include<vector>
#include "Item.h"
#include"StatMulti.h"
//multiplier class (name, number)
class Player {
private:
	Item* eqNormal[5];
	Item* eqAccs[2];
	std::vector<StatMulti*> multis{};
	int tAtk;
	int tDef;
	int tHP;
public:
	int cAtk;
	int cDef;
	int cHP;
	int gettAtk() {
		return tAtk;
	}
	int gettDef() {
		return tDef;
	}
	int gettHP() {
		return tHP;
	}
	void settAtk(int a) {
		tAtk = a;
	}
	void settDef(int a) {
		tDef = a;
	}
	void settHP(int a) {
		tHP = a;
	}
	Player(){}
	Player(int atk, int def, int hp) {
		settAtk(atk);
		settDef(def);
		settHP(hp);
			cAtk = gettAtk();
			cDef = gettDef();
			cHP = gettHP();
	}
};