#pragma once
#include <iostream>
#include "Enemy.h"
#include"Player.h"
#include <map>
#include<random>
#include<time.h>
class AdvSpace {
private:
	Player player=Player(2,2,15);
	Enemy currEnemy;
public:
	int itemStat[7][6]{ {} };//0-name,1-atk,2-def,3-mhp,4-type,5-id
	map<string, int> ItemNames;
	void setItemNames() {
		ItemNames.insert(pair<string, int>("Worn-out Helmet", 1));
		ItemNames.insert(pair<string, int>("", 2));
		ItemNames.insert(pair<string, int>("", 3));
		ItemNames.insert(pair<string, int>("", 4));
		ItemNames.insert(pair<string, int>("", 5));
		ItemNames.insert(pair<string, int>("", 6));
		ItemNames.insert(pair<string, int>("", 7));
	}
	map<string, int> CommandCode;
	void setCodeMap() {
		CommandCode.insert(pair<std::string, int>("/help", 1));
		CommandCode.insert(pair<std::string, int>("/b", 2));
		CommandCode.insert(pair<std::string, int>("/inv", 3));
		CommandCode.insert(pair<std::string, int>("/stat", 4));
	}
	void createNewEnemy(string a, int b, int c, int d,Zone e) {
		currEnemy = Enemy(a, b, c, d,e);
	}
	void destroyCurrEnemy() {
		currEnemy = Enemy("", 0, 0, 0,Zone::None);
	}
	Player* getPlayer() {
		return (&player);
	}
	Enemy* getCurrEnemy() {
		return (&currEnemy);
	}
	void enemyMoveAttack(Enemy* attacker, Player* target, int a) {
		target->cHP -= attacker->cAtk;
	}
	void playerMoveAttack(Player* attacker, Enemy* target,int a) {
		target->cHP -= attacker->cAtk;
	}
	void itemChance(Enemy* e) {
		mt19937 generator(time(nullptr));
		uniform_int_distribution<int> dist(1, 10000);
		int x = dist(generator);
		if (x >= currEnemy.getDc()) {
			cout << "Got a drop!" << endl;
			/*uniform_int_distribution<int> drop(1, 7);
			int item = drop(generator);
			switch (item) {
			case 1:
				Item()
			}*/
		}
		else {
			cout << "no item got, git gud skrub" << endl;
		}
	}
};