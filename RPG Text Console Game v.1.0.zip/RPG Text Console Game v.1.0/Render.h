#pragma once
#include "AdvSpace.h"
#include <string>
class Renderer {
public:
	void menuPrint(){
		std::cout << "/help - shows the command list \n/b - proceeds to next battle\n/inv - checks inventory\n/stat - shows player's stats\n";
		/*std::cout<<"Write /help for command list."*/ //s�u�y jako default
	}
	void enemyAppears(Enemy* enemy) {
		std::cout << enemy->getName() << " attacks!" << endl;
	}
	void printEnemyStats(Enemy* enemy) {
		std::cout << "--- -------- --- -------- --- -------- ---\n||| Atk:" << enemy->cAtk << " ||| Def:" << enemy->cDef << " ||| HP:" << enemy->cHP << "|||\n--- -------- --- -------- --- -------- ---" << std::endl;
	}
	void printPlayerStats(Player* player) {
		std::cout << "--- -------- --- -------- --- -------- ---\n||| Atk:" << player->cAtk << " ||| Def:" << player->cDef << " ||| HP:" << player->cHP << "|||\n--- -------- --- -------- --- -------- ---" << std::endl;
	}
	void printPAttack(Enemy* enemy, Player* pl, int atkType) {
		switch (atkType) {
		case 1:
			std::cout << (enemy->getName()) << " was hit for " << pl->cAtk << " damage.";
			break;
		}
		
	}
	void printEAttack(Enemy* enemy, int atkType) {
		std::cout <<"You were hit for " << enemy->cAtk << " damage.";
	}
	void printEnemyHP(Enemy* enemy) {
		cout << "(Enemy's HP: " << enemy->cHP << ")";
	}
	void printPlayerHP(Player* player) {
		cout << "(Your HP: " << player->cHP << ")";
	}
	void newLine(int a) {
		for (int i = 1; i <= a; i++) {
			std::cout << std::endl;
		}
	}
	void clear() {
		system("cls");
	}
};