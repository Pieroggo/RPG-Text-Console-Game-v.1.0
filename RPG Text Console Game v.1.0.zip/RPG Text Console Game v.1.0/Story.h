#pragma once
#include<string>
using namespace std;
class storyboard {
public:
	string story[100]{ "You wake up in a sewer, feeling dizzy and very weak. You stand up to a good look at your surroundings. ", //1
		"You see a rat in the distance. The moment it spots you, it jumps near you and tries to bite you. You decide to show the rat who is the boss.",//2
		"After defeating the rat, you turn around and see a pack of weak rats scurrying around. They seem to not notice you....yet."
		"You have decided to pick on this infestation of rats and try to get rid of it. You firstly take on the 3 rats in front of you."





	};//potem si� zwi�kszy
	void printStory(int a) {
		std::cout << story[a]<<std::endl;
	}
};
