#pragma once
#include<iostream>
#include<conio.h>
#include<string>
#include"rules.h"
#include "Render.h"
#include "AdvSpace.h"
#include "Story.h"
using namespace std;
class Game {
private:
	Renderer render;
	AdvSpace advspace;
	storyboard sb;
public:
	char inputChar;
	std::string inputString;
	char slowInput() {
		char c;
		std::cin >> c;
		return c;
	}
	char fastInput() {
		return _getch();
	}
	std::string commInput() {
		std::string a;
		std::cin >> a;
		return a;
	}
	void Run() {
		gameStart();
		system("cls");
		gamePart1();
	}
	void gamePart1() {
		advspace.createNewEnemy("Rat", 1, 1, 10,Zone::Sewers);
		Enemy* en = advspace.getCurrEnemy();
		Player* pl = advspace.getPlayer();
		sb.printStory(0);
		render.menuPrint();
		menu(en,pl);
		sb.printStory(2);
		cout << "You Win! (for now)";
		system("pause");
	}
	void menu(Enemy* e,Player* p) {
		advspace.setCodeMap();
		advspace.setItemNames();
		inputString = commInput();
		int x=advspace.CommandCode[inputString];
		cout << x << endl;
		switch (x) {
			case 1:
				render.menuPrint();
				menu(e,p);
				break;
			case 2:
				sb.printStory(1);
				batlMenu(e,p);
				break;
			case 3:
				std::cout << "Kiedy� tutaj ma byc inventory" << std::endl;
				menu(e, p);
				break;
			case 4:
				std::cout << "Stats:" << std::endl;
				render.printPlayerStats(advspace.getPlayer());
				menu(e,p);
				break;
			default:
				std::cout << "";
				menu(e,p);
				break;
			}
		}
	
	void batlMenu(Enemy* ene,Player* pla) {
		render.enemyAppears(ene);
		render.printEnemyStats(ene);
		while (advspace.getCurrEnemy()->cHP!= 0 && advspace.getPlayer()->cHP != 0) {
			char c = fastInput();
			switch (c) {
			case 'q': {
				render.printPAttack(advspace.getCurrEnemy(), advspace.getPlayer(), 1);
				advspace.playerMoveAttack(advspace.getPlayer(),advspace.getCurrEnemy(),1);
				render.printEnemyHP(advspace.getCurrEnemy());
				render.newLine(1);
				advspace.enemyMoveAttack(advspace.getCurrEnemy(), advspace.getPlayer(),1);
				render.printEAttack(advspace.getCurrEnemy(), 1);
				render.printPlayerHP(advspace.getPlayer());
				render.newLine(1);
				break;
			}
			case 'i': {
				
			}
			default:
				std::cout << "";
				break;
			}
		}
		if (advspace.getCurrEnemy()->cHP == 0) {
			cout << "You killed the " << advspace.getCurrEnemy()->getName() << "." << endl;
			advspace.itemChance(advspace.getCurrEnemy());
		}
	}
	void gameStart() {
		cout << "RPG test game: v. alpha 1.0" << endl;
		cout << "Pick an option:\n1-Play the Game\n2-Check the rules\n3-Quit" << endl;
		int a{};
		cin >> a;
		switch (a) {
		case 1: {
			
			break; }
		case 2: {
			gameRules();
			break; }
		case 3: {
			quit(0);
			break;
		}
		}
	}
	void quitBack() {
		int pick{};
		pick = _getch();
		int i = 1;
		while (i != 0) {
			switch (pick) {
			case 49: {
				i = 0;
				gameStart();
				break;
			}
			case 50: {
				i = 0;
				cout << "Options shiz" << endl;
				break;
			}
			case 51: {
				i = 0;
				gameRules();
				break;
			}
			default: {
				cout << "";
				quitBack();
				break;
			}
			}
		}
	}
	void quitCheck() {
		int c;
		c = _getch();
		int i = 1;
		while (i != 0) {

			switch (c) {
			case 27: {
				i = 0;
				exit(0);
				break;
			}
			case 13: {
				i = 0;
				cout << "Pick the menu you want to go to.\n1 - \n2- Options Menu\n3-Rules Menu" << endl;//maybe return to point in progress?
				quitBack();
				break;
			}
			default: {
				cout << "";
				quitCheck();
			}
			}
		}
	}
	void quit(int a) { //residue if i want to implement point in gameplay save
		system("cls");
		cout << "Are you sure you want to exit the game?\nPress Esc to quit. Press Enter to go back to the game" << endl;
		quitCheck();
	}	
};